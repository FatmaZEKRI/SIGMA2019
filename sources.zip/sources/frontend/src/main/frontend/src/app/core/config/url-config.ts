export class UrlConfig {

  /*
    DEV URL
  */
 public static API_URL = "http://localhost:8080";

  /*
    PROD URL
  */
  // public static API_URL = "https://sigma17.herokuapp.com";

  //public static API_URL = "/p-sigma";
}
