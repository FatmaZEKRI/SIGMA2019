import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialogConfig, MatDialog, MatSort, MatPaginator, MatTableDataSource } from '@angular/material';
import { DialogService } from '../service/dialog-service';
import { TeamService } from '../service/team.service';


@Component({
  selector: 'app-all-teams',
  templateUrl: './teams-list.component.html',
  styleUrls: ['./teams-list.component.css'],
  providers: [TeamService]
})
export class TeamListComponent implements OnInit {
  // propriété
  alladmins: any;
  dataSource = new MatTableDataSource();
  displayedColumns: string[] = ['nom', 'responsable', 'entite', 'edit', 'delete'];
  resultsLength = 0;
  searchKey: string;

  constructor(private router: Router, private teamService: TeamService, private dialog: MatDialog, private dialogService: DialogService) { }

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngOnInit(): void {
    //this.loadData();
  }

  onCreate() {
    console.log("debut onCreate()");
   
  }

  onEdit(team) {
    console.log("debut onEdit()");
  }

  onDelete(team) {

    console.log("on delete")
  }

  onDisplay() {

  }

  onSearchClear() {
    this.searchKey = "";
  }
  applyFilter() {
    const search = this.searchKey.trim().toLowerCase();
    this.dataSource.filter = search;
  }

  loadData() {
    
  }

  selectRow(row) {

  }
}


