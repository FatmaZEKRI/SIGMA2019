
export class Address {

    number: number;
    street: string;
    postalCode: number;
    city: string;
    country: string;


    constructor() {
    }

}
