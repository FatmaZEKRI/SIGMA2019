export class APE {

    codeApe: string;
    libelleApe: string;
    codeDivision: number;
    libelleDivision: string;
    
    constructor() { }

}
