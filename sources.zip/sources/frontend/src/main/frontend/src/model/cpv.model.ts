export class CPV {

    codecpv: string;
    libelleCpv: string;

    constructor() { }

}
