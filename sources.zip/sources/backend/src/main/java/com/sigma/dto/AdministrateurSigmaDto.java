package com.sigma.dto;

public class AdministrateurSigmaDto extends UtilisateurDto{
	
}
