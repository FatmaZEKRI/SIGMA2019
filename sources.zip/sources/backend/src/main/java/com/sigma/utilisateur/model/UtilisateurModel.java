package com.sigma.utilisateur.model;

public class UtilisateurModel {
    public String nom;
    public String prenom;
    public String mail;
    public String password;

    public String getNom() {
        return this.nom;
    }

    public String getPrenom() {
        return this.prenom;
    }

    public String getMail() {
        return this.mail;
    }

    public String getPassword() {
        return this.password;
    }
}
