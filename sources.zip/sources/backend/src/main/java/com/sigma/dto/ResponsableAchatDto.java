package com.sigma.dto;

public class ResponsableAchatDto extends AcheteurDto {
  
}
