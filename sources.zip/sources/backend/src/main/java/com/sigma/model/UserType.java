package com.sigma.model;

public enum UserType {
	PROVIDER,
	ADMINSIGMA,
	ADMINENTITY,
	PURCHASER,
	RESPONSABLE,
	USER
}
