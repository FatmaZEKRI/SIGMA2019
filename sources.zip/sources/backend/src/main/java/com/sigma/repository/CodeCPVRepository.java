package com.sigma.repository;

import com.sigma.model.CodeCPV;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CodeCPVRepository extends JpaRepository<CodeCPV, String>{

}
