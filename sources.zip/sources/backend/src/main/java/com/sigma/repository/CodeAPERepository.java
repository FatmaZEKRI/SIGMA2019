package com.sigma.repository;

import com.sigma.model.CodeAPE;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CodeAPERepository extends JpaRepository<CodeAPE, String> {

}
